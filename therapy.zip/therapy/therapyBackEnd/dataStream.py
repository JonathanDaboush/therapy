from therapyBackEnd.MyOwnDataGeneration import myCleanData
from therapyBackEnd.initialTrainingData import get_flan_chunks_from_books
from therapyBackEnd.sqLite import (
    getConversation, insertSummary, getSummaries
)
from therapyBackEnd.therapist import learn_from_chunk


def initialTraining():
    chunks=get_flan_chunks_from_books()
    chunks2=myCleanData()
    chunks2=chunks2[['input','target']]
    chunks.extend(chunks2.to_dict(orient="records"))
    return chunks

def prepare_flan_array_for_client(client_id: int):
   
    rows = getConversation(client_id)

    flan_data = []
    for input_text, response_text in rows:
        if input_text and response_text:
            flan_data.append({
                "input": input_text.strip(),
                "target": response_text.strip()
            })

    return flan_data

def add_summary_as_flan_thanks(client_id, summary_text, learn=True):
    """
    Inserts a summary and optionally learns from it.
    """
    insertSummary(summary_text, client_id)
    
    if learn:
        learn_from_chunk(f"Client Summary Update: \"{summary_text}\"", client_id=client_id)


    return {
        "input": summary_text.strip(),
        "target": "Thanks for the summary."
    }

def get_summary_text(client_id):
    rows = getSummaries(client_id)
    if rows and rows[-1][1]:
        return rows[-1][1].strip()
    return None


