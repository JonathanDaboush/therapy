from fastapi import FastAPI, Body, Header, HTTPException, Depends
from emailInterface import emailServiceInstance
from sqLite import (
    editConversation, insertClient, getClient, insertConversation, recursive_delete_client,
    getConversation, remove_all_conversations, removeConversation, removeSummary, upsertSummary
)
from therapist import (
    adjust_generation_by_rating, generate_response, learn_from_dialogue,
    update_train_and_gen_params, learn_from_chunk
)
from summarizer import summarize_long_text, getSummaries
from datetime import date, datetime, timedelta
import jwt
import os

SECRET_KEY = os.getenv("SECRET_KEY", "fallback_dev_key")  # Secret for JWT signing; replace in production

app = FastAPI()

def validate_required_fields(data, required_fields):
    """
    Checks if all required fields are present in the input data.
    Raises HTTPException if any are missing.
    Args:
        data (dict): The input data dictionary.
        required_fields (list): List of required field names.
    """
    missing = [field for field in required_fields if not data.get(field)]
    if missing:
        raise HTTPException(status_code=400, detail=f"Missing fields: {', '.join(missing)}")

def create_token(client_id):
    """
    Creates a JWT token for the given client_id.
    Args:
        client_id (str): The user's unique identifier.
    Returns:
        str: Encoded JWT token.
    """
    payload = {
        "sub": client_id,
        "exp": datetime.utcnow() + timedelta(hours=12)  # Token expires in 12 hours
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

def verify_token(authorization: str = Header(...)):
    """
    Dependency for protected routes. Verifies the JWT token from the Authorization header.
    Args:
        authorization (str): The 'Authorization' header value ("Bearer <token>").
    Returns:
        str: The client_id (subject) from the token if valid.
    Raises:
        HTTPException: If the token is missing, invalid, or expired.
    """
    try:
        parts = authorization.split(" ")
        if len(parts) != 2 or parts[0] != "Bearer":
            raise HTTPException(status_code=401, detail="Invalid authorization format")
        token = parts[1]
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return payload["sub"]
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

@app.post("/forgotPassword")
def forgot_password(data: dict = Body(...)):
    """
    Sends a password reset email to the user.
    Parameters:
        data (dict): Must include 'email' and 'subject'.
    Returns:
        dict: Success or error message.
    """
    validate_required_fields(data, ["email", "subject"])
    try:
        subject, body = "Password Reset", "You requested a reset. Please check your email."
        emailServiceInstance.send_email(data["email"], subject, body)
        return {"message": "Password reset email sent."}
    except Exception as e:
        return {"error": str(e)}

@app.post("/signUp")
def sign_up(data: dict = Body(...)):
    """
    Registers a new user and sends a confirmation email.
    Parameters:
        data (dict): Must include 'new_username', 'new_email', 'new_password', 'subject'.
    Returns:
        dict: Success or error message.
    """
    validate_required_fields(data, ["new_username", "new_email", "new_password", "subject"])
    try:
        insertClient(data["new_username"], data["new_email"], data["new_password"])
        subject, body = data["subject"], "Welcome to TherapyAI!"
        emailServiceInstance.send_email(data["new_email"], subject, body)
        return {"message": "Confirmation email sent."}
    except ValueError as e:
        return {"error": str(e)}
    except Exception as e:
        return {"error": str(e)}

@app.post("/logIn")
def log_in(data: dict = Body(...)):
    """
    Authenticates a user and returns a JWT token if successful.
    Parameters:
        data (dict): Must include 'username' and 'password'.
    Returns:
        dict: {'token': <JWT>, 'client_id': <username>} on success, or error message.
    """
    validate_required_fields(data, ["username", "password"])
    client = getClient(data["username"], data["password"])
    if client:
        token = create_token(data["username"])
        return {"token": token, "client_id": data["username"]}
    return {"error": "Invalid username or password"}

@app.post("/deleteAccount")
def delete_account(data: dict = Body(...), client_id=Depends(verify_token)):
    """
    Deletes the user's account and sends a notification email.
    Parameters:
        data (dict): Must include 'to_email' and 'subject'.
        client_id (str): Extracted from JWT token.
    Returns:
        dict: Success message.
    """
    validate_required_fields(data, ["to_email", "subject"])
    recursive_delete_client(client_id)
    subject, body = data["subject"], "Your account has been deleted."
    emailServiceInstance.send_email(data["to_email"], subject, body)
    return {"message": "Account deleted and notification email sent."}

@app.post("/rating")
def rating(data: dict = Body(...), client_id=Depends(verify_token)):
    """
    Receives a user rating and adjusts the AI model accordingly.
    Parameters:
        data (dict): Must include 'rating' (int, 1-5).
        client_id (str): Extracted from JWT token.
    Returns:
        dict: Success message.
    """
    validate_required_fields(data, ["rating"])
    rating_value = data["rating"]
    if not isinstance(rating_value, int) or not 1 <= rating_value <= 5:
        raise HTTPException(status_code=400, detail="Rating must be between 1 and 5")
    adjust_generation_by_rating(rating_value)
    return {"message": "Rating applied"}

@app.post("/fineTune")
def fine_tuning(data: dict = Body(...), client_id=Depends(verify_token)):
    """
    Updates fine-tuning parameters for the AI model.
    Parameters:
        data (dict): Fine-tuning parameters (epochs, batch size, etc.).
        client_id (str): Extracted from JWT token.
    Returns:
        dict: Success message.
    """
    update_train_and_gen_params(data)
    return {"message": "Fine-tuning parameters updated"}

@app.post("/editChat")
def edit_chat(data: dict = Body(...), client_id=Depends(verify_token)):
    """
    Edits a specific conversation entry.
    Parameters:
        data (dict): Must include 'conversation_id', 'new_input', 'new_response'.
        client_id (str): Extracted from JWT token.
    Returns:
        dict: Message with number of rows updated.
    """
    validate_required_fields(data, ["conversation_id", "new_input", "new_response"])
    updated = editConversation(client_id, data["conversation_id"], data["new_input"], data["new_response"])
    return {"message": f"Conversation updated ({updated} row(s))"}

@app.post("/generate")
def response(data: dict = Body(...), client_id=Depends(verify_token)):
    """
    Generates a therapist response to the user's message, saves the conversation, and returns the response.
    Parameters:
        data (dict): Must include 'message'.
        client_id (str): Extracted from JWT token.
    Returns:
        dict: {'response': <generated_text>}
    """
    validate_required_fields(data, ["message"])
    generated_text = generate_response(data["message"], client_id)
    learn_from_dialogue(data["message"], generated_text, client_id)
    today = date.today().isoformat()
    insertConversation(data["message"], generated_text, today, client_id)
    return {"response": generated_text}

@app.get("/summarize")
def summarize(client_id=Depends(verify_token)):
    """
    Summarizes the user's chat history and saves the summary.
    Parameters:
        client_id (str): Extracted from JWT token.
    Returns:
        dict: {'summary': <summary_text>}
    """
    summary_text = summarize_long_text(client_id=client_id)
    upsertSummary(summary_text, client_id)
    return {"summary": summary_text}

@app.get("/catchup")
def catch_up(client_id=Depends(verify_token)):
    """
    Retrieves all summaries for the user.
    Parameters:
        client_id (str): Extracted from JWT token.
    Returns:
        dict: {'summaries': [<summary1>, <summary2>, ...]}
    """
    summaries = getSummaries(client_id)
    return {"summaries": [s[1] for s in summaries]}

@app.post("/clearConversations")
def clear_conversations(client_id=Depends(verify_token)):
    """
    Deletes all conversations for the user.
    Parameters:
        client_id (str): Extracted from JWT token.
    Returns:
        dict: Message with number of conversations removed.
    """
    deleted = remove_all_conversations(client_id)
    return {"message": f"{deleted} conversation(s) removed."}

@app.post("/clearSummaries")
def clear_summaries(client_id=Depends(verify_token)):
    """
    Deletes all summaries for the user.
    Parameters:
        client_id (str): Extracted from JWT token.
    Returns:
        dict: Message with number of summaries removed.
    """
    deleted = removeSummary(client_id)
    return {"message": f"{deleted} summary(s) removed."}

if __name__ == "__main__":
    import uvicorn
    # Runs the FastAPI app with auto-reload enabled for development
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
