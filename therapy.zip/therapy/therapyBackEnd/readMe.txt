# TherapyAI Backend

This is the backend for the TherapyAI platform, providing RESTful APIs for user authentication, chat with an AI therapist, feedback, fine-tuning, and more. It is built with [FastAPI](https://fastapi.tiangolo.com/) and leverages Hugging Face Transformers, SQLite, and various data science libraries.

---

## Features

- **User Management**: Sign up, log in, password reset, and account deletion with JWT authentication.
- **Therapy Chat**: AI-powered therapist chat, with conversation history and summaries.
- **Feedback**: Accepts user ratings to adjust AI generation parameters.
- **Fine-Tuning**: Allows users to submit custom data and parameters to fine-tune their own AI model.
- **Summarization**: Summarizes chat history using a transformer-based model.
- **Email Notifications**: Sends emails for account actions (requires SMTP configuration).
- **PDF & Data Handling**: Loads and processes PDF books and various datasets for training.

---

## Project Structure

- `app.py` — Main FastAPI application and API endpoints.
- `sqLite.py` — SQLite database operations and schema.
- `therapist.py` — Model loading, generation, and fine-tuning logic.
- `summarizer.py` — Summarization model and utilities.
- `emailInterface.py` — Email sending and validation.
- `initialTrainingData.py`, `MyOwnDataGeneration.py`, `dataStream.py` — Data loading and formatting utilities.
- `requirements.txt` — Python dependencies.
- `Dockerfile`, `docker-compose.yml` — For containerized deployment.
- `.env` — Environment variables (see below).

---

## Environment Variables

Configure your environment variables in `.env` (see sample below):

```env
DEBUG=True
APP_ENV=development

EMAIL_ENABLED = True
EMAIL_SMTP_SERVER = "smtp.gmail.com"
EMAIL_SMTP_PORT = 465
EMAIL_SMTP_USER = "your_email@gmail.com"
EMAIL_SMTP_PASSWORD = "your_password"
EMAIL_SENDER_NAME = "TherapyAI Platform"
EMAIL_SENDER_ADDRESS = "your_email@gmail.com"
EMAIL_USE_SSL = True
EMAIL_USE_TLS = False
EMAIL_DEFAULT_SUBJECT = "TherapyAI Notification"
```

---

## Setup & Installation

### 1. Python Dependencies

Install all Python dependencies:

```sh
pip install -r requirements.txt
```

### 2. Node.js (NPM) Dependencies

Some features (e.g., PDF or DOCX conversion, or if you use Node.js scripts for data prep) may require Node.js packages.  
**If you need to use npm for any backend scripts, install:**

```sh
npm install pdf2docx docx2pdf
```

> **Note:** These are only needed if you use Node.js-based scripts for document conversion. The backend itself is Python-based.

### 3. Database

The SQLite database is initialized automatically on first run (`therapy.db`).

---

## Running the Backend

### Development (with auto-reload):

```sh
uvicorn app:app --reload
```

### Production (Docker):

```sh
docker-compose up --build
```

This will build and run the backend in a Docker container, exposing port 8000.

---

## API Endpoints

- `POST /signUp` — Register a new user.
- `POST /logIn` — Authenticate and receive JWT.
- `POST /forgotPassword` — Request password reset email.
- `POST /deleteAccount` — Delete user account (JWT required).
- `POST /rating` — Submit feedback rating (JWT required).
- `POST /fineTune` — Submit fine-tuning parameters (JWT required).
- `POST /editChat` — Edit a chat entry (JWT required).
- `POST /generate` — Generate therapist response (JWT required).
- `GET /summarize` — Summarize chat history (JWT required).
- `GET /catchup` — Get all summaries (JWT required).
- `POST /clearConversations` — Delete all conversations (JWT required).
- `POST /clearSummaries` — Delete all summaries (JWT required).

See `app.py` for detailed endpoint documentation.

---

## Docker Usage

- **Build and run:**  
  ```sh
  docker-compose up --build
  ```
- **Stop:**  
  ```sh
  docker-compose down
  ```

---

## Notes

- The backend is designed to work with the TherapyAI frontend (see frontend repo).
- Make sure to set all required environment variables, especially for email functionality.
- For production, use secure secrets and disable debug mode.

---

## License

This project is private and not intended for public distribution. Please contact the author for licensing information.

---

## Author

Developed by Jonathan Daboush.