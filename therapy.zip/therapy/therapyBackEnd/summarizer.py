import torch
import re
from collections import Counter
from transformers import LEDTokenizer, LEDForConditionalGeneration

MODEL_NAME = "allenai/led-base-16384"
MODEL_SAVE_PATH = "./led_model_checkpoint"

led_tokenizer = None
led_model = None

def load_led_components(model_path=MODEL_SAVE_PATH, fallback_model=MODEL_NAME):
    """
    Loads the LED tokenizer and model, preferring a local checkpoint if available.
    Args:
        model_path (str): Path to a saved model checkpoint.
        fallback_model (str): Model name to use if checkpoint is unavailable.
    Side Effects:
        Sets global led_tokenizer and led_model.
    Logic:
    - Loads the tokenizer from the fallback model name.
    - Tries to load the model from the checkpoint; if it fails, loads from the fallback model.
    """
    global led_tokenizer, led_model
    led_tokenizer = LEDTokenizer.from_pretrained(fallback_model)
    try:
        led_model = LEDForConditionalGeneration.from_pretrained(model_path)
        print("[INFO] Loaded model from checkpoint.")
    except (OSError, ValueError) as e:
        print(f"[WARN] Failed to load from checkpoint: {e}")
        print("[INFO] Falling back to base model.")
        led_model = LEDForConditionalGeneration.from_pretrained(fallback_model)

def save_led_model(path=MODEL_SAVE_PATH):
    """
    Saves the current LED model and tokenizer to disk.
    Args:
        path (str): Directory path to save the model and tokenizer.
    Side Effects:
        Writes model and tokenizer files to disk.
    """
    if led_model and led_tokenizer:
        led_model.save_pretrained(path)
        led_tokenizer.save_pretrained(path)
        print(f"[INFO] Model and tokenizer saved to {path}")

def chunk_text_by_tokens(text, max_tokens=4000, tokenizer=None):
    """
    Splits text into chunks based on token count using the provided tokenizer.
    Args:
        text (str): The input text to chunk.
        max_tokens (int): Maximum tokens per chunk.
        tokenizer (LEDTokenizer, optional): Tokenizer to use. Defaults to global led_tokenizer.
    Returns:
        list: List of text chunks (strings).
    Logic:
    - Splits the text into words.
    - Iteratively adds words to a chunk until the token count exceeds max_tokens.
    - Starts a new chunk when the limit is reached.
    - Returns all chunks as a list.
    """
    if tokenizer is None:
        tokenizer = led_tokenizer

    words = text.split()
    chunks = []
    current_chunk = []

    for word in words:
        current_chunk.append(word)
        tokenized = tokenizer(" ".join(current_chunk), return_tensors="pt", truncation=False)
        if tokenized.input_ids.shape[1] > max_tokens:
            chunks.append(" ".join(current_chunk[:-1]))
            current_chunk = [word]

    if current_chunk:
        chunks.append(" ".join(current_chunk))

    return chunks

def extract_factual_terms(text, max_terms=15):
    """
    Extracts key factual terms (e.g., medical terms, numbers, long words) from the text.
    Args:
        text (str): The input text.
        max_terms (int): Maximum number of terms to extract.
    Returns:
        list: List of unique factual terms (lowercased).
    Logic:
    - Uses a regex to find numbers, medical terms, and long words.
    - Counts occurrences and returns the most common terms up to max_terms.
    """
    pattern = re.compile(
        r'\b(?:\d+(?:\.\d+)?(?:mg|ml|%)?|'
        r'[A-Z][a-z]{2,}(?:osis|itis|oma|emia|graphy|logy|pathy|ectomy|therapy|tomy|algia)|'
        r'[a-zA-Z_]{5,})\b'
    )
    matches = pattern.findall(text)
    term_counts = Counter(matches)
    most_common = [term.lower() for term, _ in term_counts.most_common(max_terms)]
    return list(set(most_common))

def prepare_led_inputs(text, tokenizer, max_length=4096, factual_terms=None):
    """
    Prepares input tensors and global attention mask for the LED model.
    Args:
        text (str): The input text.
        tokenizer (LEDTokenizer): Tokenizer to use.
        max_length (int): Maximum input length for the model.
        factual_terms (list, optional): List of terms to focus global attention on.
    Returns:
        tuple: (inputs, global_attention_mask)
            - inputs: Tokenized input tensors.
            - global_attention_mask: Tensor indicating which tokens get global attention.
    Logic:
    - Tokenizes the input text.
    - Sets global attention on tokens matching factual_terms and always on the first token.
    """
    inputs = tokenizer(
        text,
        return_tensors="pt",
        max_length=max_length,
        padding="max_length",
        truncation=True
    )

    global_attention_mask = torch.zeros_like(inputs.input_ids)
    input_tokens = tokenizer.convert_ids_to_tokens(inputs.input_ids[0])

    if factual_terms:
        for i, token in enumerate(input_tokens):
            if any(term.lower() in token.lower() for term in factual_terms):
                global_attention_mask[0, i] = 1

    global_attention_mask[:, 0] = 1  # Always pay attention to first token
    return inputs, global_attention_mask

def summarize_with_led(
    text,
    model=None,
    tokenizer=None,
    max_input_length=4096,
    max_output_length=256,
    factual_terms=None
):
    """
    Summarizes the input text using the LED model.
    Args:
        text (str): The text to summarize.
        model (LEDForConditionalGeneration, optional): Model to use. Defaults to global led_model.
        tokenizer (LEDTokenizer, optional): Tokenizer to use. Defaults to global led_tokenizer.
        max_input_length (int): Maximum input length for the model.
        max_output_length (int): Maximum length of the summary.
        factual_terms (list, optional): List of terms to focus global attention on.
    Returns:
        str: The generated summary text.
    Logic:
    - Prepares model inputs and attention mask.
    - Calls model.generate() to produce the summary.
    - Decodes and returns the summary text.
    - Returns an empty string if generation fails.
    """
    if model is None:
        model = led_model
    if tokenizer is None:
        tokenizer = led_tokenizer

    inputs, global_attention_mask = prepare_led_inputs(text, tokenizer, max_input_length, factual_terms)

    try:
        summary_ids = model.generate(
            input_ids=inputs.input_ids,
            attention_mask=inputs.attention_mask,
            global_attention_mask=global_attention_mask,
            max_length=max_output_length,
            num_beams=4,
            length_penalty=2.0,
            early_stopping=True
        )
        return tokenizer.decode(summary_ids[0], skip_special_tokens=True)
    except Exception as e:
        print(f"[ERROR] Failed to generate summary: {e}")
        return ""

# Initialize model and tokenizer at import time
load_led_components()

