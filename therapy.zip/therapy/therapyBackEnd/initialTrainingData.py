import fitz
import re
import pandas as pd
from transformers import T5Tokenizer

# Optional tokenizer caching
_tokenizer_instance = None
def get_tokenizer():
    """
    Loads and caches the T5 tokenizer for FLAN-T5.
    Returns:
        T5Tokenizer: The tokenizer instance.
    """
    global _tokenizer_instance
    if _tokenizer_instance is None:
        _tokenizer_instance = T5Tokenizer.from_pretrained("google/flan-t5-base")
    return _tokenizer_instance

# Corrected alias
def getBookPathsFromDirectory(directory='therapyBackEnd/books'):
    """
    Recursively finds all PDF book paths in the given directory.
    Args:
        directory (str): Directory to search for PDF files.
    Returns:
        list: List of file paths to PDF books.
    """
    import os
    bookPaths = []
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.pdf'):
                bookPaths.append(os.path.join(root, file))
    return bookPaths

# Helper for FLAN formatting
def dialogueToFormat(prompt, response):
    """
    Formats a prompt-response pair for FLAN-style training.
    Args:
        prompt (str): The user's input.
        response (str): The therapist's response.
    Returns:
        dict: Dictionary with 'input' and 'target' keys.
    """
    return {"input": prompt, "target": response}

# 1. Extract text from PDF
def extract_text_from_pdf(pdf_path):
    """
    Extracts all text from a PDF file.
    Args:
        pdf_path (str): Path to the PDF file.
    Returns:
        str: The extracted text.
    """
    doc = fitz.open(pdf_path)
    return "\n".join(page.get_text() for page in doc)

# 2. Chunk paragraphs by word count
def chunk_text_into_blobs(text, max_words=400):
    """
    Splits text into chunks based on paragraph boundaries and a maximum word count.
    Args:
        text (str): The input text.
        max_words (int): Maximum words per chunk.
    Returns:
        list: List of text chunks.
    """
    paragraphs = re.split(r'\n\s*\n', text.strip())
    chunks, current_chunk, current_words = [], [], 0

    for para in paragraphs:
        words = para.split()
        if current_words + len(words) > max_words:
            chunks.append("\n\n".join(current_chunk))
            current_chunk, current_words = [para], len(words)
        else:
            current_chunk.append(para)
            current_words += len(words)

    if current_chunk:
        chunks.append("\n\n".join(current_chunk))
    return chunks

# 3. FLAN formatting
def format_for_flan_book_learning(chunk):
    """
    Formats a book chunk for FLAN-style learning.
    Args:
        chunk (str): The text chunk.
    Returns:
        dict: FLAN-formatted dictionary.
    """
    return {
        "input": f"You are a helpful AI therapist learning from medical documents. Learn this: \"{chunk}\"",
        "target": "Understood."
    }

# 4. Token-level chunking (with deduplication)
def chunk_text_by_tokens(text, max_tokens=450, tokenizer=None):
    """
    Splits text into chunks based on token count using the provided tokenizer.
    Args:
        text (str): The input text.
        max_tokens (int): Maximum tokens per chunk.
        tokenizer (T5Tokenizer, optional): Tokenizer to use.
    Returns:
        list: List of text chunks (strings).
    """
    if tokenizer is None:
        tokenizer = get_tokenizer()

    words = text.split()
    chunks = []
    current_chunk = []

    for word in words:
        current_chunk.append(word)
        tokenized = tokenizer(" ".join(current_chunk), truncation=False, return_tensors="pt")
        if tokenized.input_ids.shape[1] > max_tokens:
            chunks.append(" ".join(current_chunk[:-1]))
            current_chunk = [word]

    if current_chunk:
        chunks.append(" ".join(current_chunk))

    # Remove duplicates
    return list(set(chunks))

# 5. DB input -> FLAN formatting
def therapistInputAndResponse(listOfExamples):
    """
    Converts a list of (prompt, response) pairs into FLAN format, skipping any with missing values.
    Args:
        listOfExamples (list): List of (prompt, response) tuples.
    Returns:
        list: List of FLAN-formatted dictionaries.
    """
    data_to_return = []
    for row in listOfExamples:
        if pd.isna(row[0]) or pd.isna(row[1]):
            continue
        data_to_return.append(dialogueToFormat(row[0], row[1]))
    return data_to_return

# 6. Load from SQLite
def load_from_db(client_id=None):
    """
    Loads conversation data from the SQLite database for FLAN formatting.
    Args:
        client_id (optional): If provided, loads data for a specific client.
    Returns:
        list: List of conversation data.
    """
    try:
        from sqLite import get_conversations_for_flan, export_all_clients_for_flan
    except ImportError:
        print("[WARN] DB import failed. Are you running standalone?")
        return []

    if client_id is not None:
        return get_conversations_for_flan(client_id)
    return export_all_clients_for_flan()

# 7. Generate FLAN chunks from books
def get_flan_chunks_from_books(book_dir='therapyBackEnd/books', max_words=400):
    """
    Loads all PDF books from a directory, chunks their text, and formats for FLAN learning.
    Args:
        book_dir (str): Directory containing PDF books.
        max_words (int): Maximum words per chunk (not used if token chunking is used).
    Returns:
        list: List of FLAN-formatted dictionaries.
    """
    book_paths = getBookPathsFromDirectory(book_dir)
    tokenizer = get_tokenizer()
    all_chunks = []

    for pdf_path in book_paths:
        text = extract_text_from_pdf(pdf_path)
        chunks = chunk_text_by_tokens(text, max_tokens=600, tokenizer=tokenizer)
        all_chunks.extend(chunks)

    # Deduplicate again in case multiple books overlap
    all_chunks = list(set(all_chunks))
    flan_data = [format_for_flan_book_learning(chunk) for chunk in all_chunks]
    return flan_data
