import sqlite3
import bcrypt
import threading
import re

db_lock = threading.Lock()
DB_PATH = "therapy.db"

# Valid identifiers for safety
VALID_TABLES = {
    "client": {"id", "username", "email", "password"},
    "communication": {"id", "input", "response", "date_of_input", "client_id"},
    "summaries": {"id", "summary", "client_id"},
    "reset_tokens": {"token", "username", "expires_at"},
    "cooldowns": {"username", "last_request_ts"}
}

def is_strong_password(password):
    """
    Checks if the password meets strength requirements.
    Args:
        password (str): The password to check.
    Returns:
        bool: True if strong, False otherwise.
    """
    return re.match(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{6,}$', password)

def validate_identifiers(table, columns):
    """
    Validates that the table and columns are allowed to prevent SQL injection.
    Args:
        table (str): Table name.
        columns (list or str): Column names.
    Raises:
        ValueError: If table or columns are invalid.
    """
    if table not in VALID_TABLES:
        raise ValueError(f"Invalid table: {table}")
    if columns:
        for col in columns if isinstance(columns, list) else [columns]:
            if col not in VALID_TABLES[table]:
                raise ValueError(f"Invalid column '{col}' in table '{table}'")

def initialize_db():
    """
    Initializes the SQLite database and creates tables if they do not exist.
    """
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("PRAGMA foreign_keys = ON")
        cur = conn.cursor()
        cur.executescript("""
        CREATE TABLE IF NOT EXISTS client (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS communication (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            input TEXT NOT NULL,
            response TEXT,
            date_of_input TEXT NOT NULL,
            client_id INTEGER NOT NULL,
            FOREIGN KEY (client_id) REFERENCES client(id)
        );
        CREATE TABLE IF NOT EXISTS summaries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            summary TEXT NOT NULL,
            client_id INTEGER NOT NULL,
            FOREIGN KEY (client_id) REFERENCES client(id)
        );
        CREATE TABLE IF NOT EXISTS reset_tokens (
            token TEXT PRIMARY KEY,
            username TEXT NOT NULL,
            expires_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS cooldowns (
            username TEXT PRIMARY KEY,
            last_request_ts INTEGER NOT NULL
        );
        """)
        conn.commit()

initialize_db()

def crudOperation(operation, table, columns=None, values=None, where=None, where_args=None):
    """
    General-purpose CRUD operation for the database.
    Args:
        operation (str): One of 'insert', 'update', 'delete', 'select'.
        table (str): Table name.
        columns (list or str, optional): Columns to use.
        values (list, optional): Values for insert/update.
        where (str, optional): WHERE clause (without 'WHERE').
        where_args (list, optional): Arguments for WHERE clause.
    Returns:
        Depends on operation:
            - insert: lastrowid (int)
            - update/delete: rowcount (int)
            - select: list of tuples (rows)
    Raises:
        RuntimeError: On SQL or logic errors.
    """
    validate_identifiers(table, columns if operation in ("insert", "update", "select") else None)
    with db_lock, sqlite3.connect(DB_PATH) as conn:
        conn.execute("PRAGMA foreign_keys = ON")
        cur = conn.cursor()
        try:
            if operation == 'insert':
                sql = f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({', '.join(['?'] * len(values))})"
                cur.execute(sql, values)
                conn.commit()
                return cur.lastrowid
            elif operation == 'update':
                set_clause = ', '.join([f"{col}=?" for col in columns])
                sql = f"UPDATE {table} SET {set_clause} WHERE {where}"
                cur.execute(sql, values + where_args)
                conn.commit()
                return cur.rowcount
            elif operation == 'delete':
                sql = f"DELETE FROM {table} WHERE {where}"
                cur.execute(sql, where_args)
                conn.commit()
                return cur.rowcount
            elif operation == 'select':
                if isinstance(columns, str):
                    sql = f"SELECT {columns} FROM {table}"
                else:
                    sql = f"SELECT {', '.join(columns)} FROM {table}"
                if where:
                    sql += f" WHERE {where}"
                    cur.execute(sql, where_args or [])
                else:
                    cur.execute(sql)
                return cur.fetchall()
            else:
                raise ValueError("Invalid operation specified.")
        except Exception as e:
            raise RuntimeError(f"[DB ERROR] {operation.upper()} on {table}: {e}") from e

def insertClient(username, email, password):
    """
    Inserts a new client into the database after hashing the password.
    Args:
        username (str): The user's username.
        email (str): The user's email.
        password (str): The user's plaintext password.
    Returns:
        int: The new client's row ID.
    Raises:
        ValueError: If the password is not strong enough.
    """
    if not is_strong_password(password):
        raise ValueError("Password does not meet strength requirements.")
    hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
    return crudOperation("insert", "client", ["username", "email", "password"], [username, email, hashed_password])

def check_user_credentials(username, password):
    """
    Checks if the provided username and password match a client in the database.
    Args:
        username (str): The user's username.
        password (str): The user's plaintext password.
    Returns:
        bool: True if credentials are valid, False otherwise.
    """
    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("PRAGMA foreign_keys = ON")
            cur = conn.cursor()
            cur.execute("SELECT password FROM client WHERE username = ?", [username])
            result = cur.fetchone()
            if result and bcrypt.checkpw(password.encode(), result[0]):
                return True
    except Exception as e:
        print(f"[ERROR] check_user_credentials failed: {e}")
    return False

def getClient(username, password):
    """
    Retrieves client info if credentials are valid.
    Args:
        username (str): The user's username.
        password (str): The user's plaintext password.
    Returns:
        dict or None: {'username': username} if valid, else None.
    """
    if check_user_credentials(username, password):
        return {"username": username}
    return None

def recursive_delete_client(username):
    """
    Deletes a client and all related data from the database.
    Args:
        username (str): The user's username.
    Raises:
        ValueError: If the user does not exist.
    """
    with db_lock, sqlite3.connect(DB_PATH) as conn:
        conn.execute("PRAGMA foreign_keys = ON")
        cur = conn.cursor()
        user_id = cur.execute("SELECT id FROM client WHERE username = ?", (username,)).fetchone()
        if not user_id:
            raise ValueError(f"No user found with username: {username}")
        cur.execute("DELETE FROM client WHERE id = ?", (user_id[0],))
        conn.commit()

def editConversation(client_id, conversation_id, new_input, new_response):
    """
    Updates a conversation's input and response.
    Args:
        client_id (int): The client's ID.
        conversation_id (int): The conversation's ID.
        new_input (str): The new input text.
        new_response (str): The new response text.
    Returns:
        int: Number of rows updated.
    """
    return crudOperation(
        "update", "communication",
        ["input", "response"],
        [new_input, new_response],
        "id = ? AND client_id = ?", [conversation_id, client_id]
    )

def insertConversation(input_text, response_text, date_str, client_id):
    """
    Inserts a new conversation into the database.
    Args:
        input_text (str): The user's message.
        response_text (str): The AI's response.
        date_str (str): The date of the conversation.
        client_id (int): The client's ID.
    Returns:
        int: The new conversation's row ID.
    """
    return crudOperation(
        "insert", "communication",
        ["input", "response", "date_of_input", "client_id"],
        [input_text, response_text, date_str, client_id]
    )

def getConversation(client_id):
    """
    Retrieves all conversations for a client.
    Args:
        client_id (int): The client's ID.
    Returns:
        list: List of (input, response) tuples.
    """
    return crudOperation("select", "communication", ["input", "response"], "client_id = ?", [client_id])

def getClientByEmail(email):
    """
    Retrieves a username by email address.
    Args:
        email (str): The user's email.
    Returns:
        str or None: Username if found, else None.
    """
    results = crudOperation("select", "client", ["username"], "email = ?", [email])
    return results[0][0] if results else None

def getSummaries(client_id):
    """
    Retrieves all summaries for a client.
    Args:
        client_id (int): The client's ID.
    Returns:
        list: List of (id, summary) tuples.
    """
    return crudOperation("select", "summaries", ["id", "summary"], "client_id = ?", [client_id])

def removeConversation(client_id, conversation_id):
    """
    Deletes a specific conversation for a client.
    Args:
        client_id (int): The client's ID.
        conversation_id (int): The conversation's ID.
    Returns:
        int: Number of rows deleted.
    """
    return crudOperation("delete", "communication", where="id = ? AND client_id = ?", where_args=[conversation_id, client_id])

def removeSummary(client_id):
    """
    Deletes all summaries for a client.
    Args:
        client_id (int): The client's ID.
    Returns:
        int: Number of rows deleted.
    """
    return crudOperation("delete", "summaries", where="client_id = ?", where_args=[client_id])

def remove_all_conversations(client_id):
    """
    Deletes all conversations for a client.
    Args:
        client_id (int): The client's ID.
    Returns:
        int: Number of rows deleted.
    """
    return crudOperation("delete", "communication", where="client_id = ?", where_args=[client_id])

def get_conversations_for_flan(client_id):
    """
    Retrieves all conversations for a client in FLAN format.
    Args:
        client_id (int): The client's ID.
    Returns:
        list: List of dicts with 'input' and 'target' keys.
    """
    rows = getConversation(client_id)
    return [{"input": r[0], "target": r[1]} for r in rows if r[0] and r[1]]

def export_all_clients_for_flan():
    """
    Retrieves all conversations for all clients in FLAN format.
    Returns:
        list: List of (input, response) tuples.
    """
    return crudOperation("select", "communication", ["input", "response"], None, None)

def upsertSummary(summary, client_id):
    """
    Updates an existing summary for a client, or inserts a new one if none exists.
    Args:
        summary (str): The summary text.
        client_id (int): The client's ID.
    Returns:
        int: Number of rows updated or inserted.
    """
    existing = crudOperation("select", "summaries", ["id"], "client_id = ?", [client_id])
    if existing:
        return crudOperation("update", "summaries", ["summary"], [summary], "client_id = ?", [client_id])
    return crudOperation("insert", "summaries", ["summary", "client_id"], [summary, client_id])
