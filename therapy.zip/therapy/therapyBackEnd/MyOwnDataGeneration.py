import pandas as pd
from datasets import load_dataset

def myCleanData():
    """
    Loads and standardizes multiple therapy-related datasets from CSV files and HuggingFace datasets.
    Returns:
        pd.DataFrame: A DataFrame with columns ['input', 'target'] containing all merged and cleaned data.
    Logic:
    - Loads three local CSV datasets and selects relevant columns.
    - Cleans and standardizes column names to 'input' and 'target'.
    - Loads two HuggingFace datasets, both train and test splits, and renames columns.
    - Concatenates all datasets into a single DataFrame and drops any rows with missing values.
    """
    # Load CSV-based datasets
    df1 = pd.read_csv('data/train.csv')[['Response', 'Context']].dropna()
    df2 = pd.read_csv('data/Psych_data.csv')
    df2['Question'] = df2['Question'].str.replace(r'^.*?:\s*', '', regex=True)
    df2 = df2[['Answer', 'Question']].dropna()
    df3 = pd.read_csv('data/reddit_text-davinci-002.csv').dropna()

    # Standardize column names
    df1.columns = ['target', 'input']
    df2.columns = ['target', 'input']
    df3.columns = ['input', 'target']  # Already in correct format

    # Load HuggingFace datasets using `datasets` lib
    hf_dataset_1 = load_dataset("RishiKompelli/TherapyDataset", split="train").to_pandas()
    hf_dataset_2_train = load_dataset("fadodr/mental_health_therapy", split="train").to_pandas().drop(columns=["instruction"])
    hf_dataset_2_test = load_dataset("fadodr/mental_health_therapy", split="test").to_pandas().drop(columns=["instruction"])

    # Rename HuggingFace columns
    for df in [hf_dataset_1, hf_dataset_2_train, hf_dataset_2_test]:
        df.columns = ['input', 'target']

    # Merge all into one DataFrame
    dataFrameFinal = pd.concat([df1, df2, df3, hf_dataset_1, hf_dataset_2_train, hf_dataset_2_test], ignore_index=True)
    dataFrameFinal.dropna(inplace=True)

    return dataFrameFinal

def getBookPathFromDirectory(directory='therapyBackEnd/books'):
    """
    Recursively finds all PDF book paths in the given directory.
    Args:
        directory (str): Directory to search for PDF files.
    Returns:
        list: List of file paths to PDF books.
    Logic:
    - Walks through the directory and subdirectories.
    - Collects all files ending with '.pdf' and returns their full paths.
    """
    import os
    bookPaths = []
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.pdf'):
                bookPaths.append(os.path.join(root, file))
    return bookPaths
