import os
import json
import threading
from transformers import T5Tokenizer, T5ForConditionalGeneration, TrainingArguments, Trainer
from datasets import Dataset

CONFIG_PATH = "therapist_config.json"
DEFAULT_CONFIG = {
    "model_name": "google/flan-t5-base",
    "max_length": 768,
    "batch_size": 8,
    "num_epochs": 3,
    "learning_rate": 5e-5,
    "weight_decay": 0.01,
    "warmup_steps": 200,
    "eval_steps": 500,
    "logging_steps": 100,
    "fp16": True
}
DEFAULT_RESULTS = {
    "top_k": 50,
    "top_p": 0.95,
    "temperature": 0.8
}

def load_config(path=CONFIG_PATH):
    """
    Loads model and generation configuration from a JSON file if it exists, otherwise uses defaults.
    Args:
        path (str): Path to the config file.
    Returns:
        tuple: (config dict, results dict)
    """
    if os.path.exists(path):
        with open(path, "r") as f:
            data = json.load(f)
            return data.get("config", DEFAULT_CONFIG), data.get("results", DEFAULT_RESULTS)
    return DEFAULT_CONFIG, DEFAULT_RESULTS

CONFIG, results = load_config()

model_cache = {}      # Caches models per client_id for efficiency
model_locks = {}      # Locks for thread-safe model loading/training per client
cache_lock = threading.Lock()
AUTO_SAVE = True      # If True, models are saved after training

def update_config(new_config):
    """
    Updates the global CONFIG dictionary and clears the model cache.
    Args:
        new_config (dict): New configuration values.
    Side Effects:
        Updates CONFIG and clears model_cache.
    """
    global CONFIG
    CONFIG.update(new_config)
    with cache_lock:
        model_cache.clear()
        print("[CONFIG] Model cache cleared due to config update.")

def update_results(new_results):
    """
    Updates the global results dictionary.
    Args:
        new_results (dict): New generation parameters.
    """
    global results
    results.update(new_results)

def update_train_and_gen_params(params):
    """
    Updates training and generation parameters from a parameter dictionary.
    Args:
        params (dict): Parameters to update (batch_size, num_epochs, learning_rate, etc.).
    Side Effects:
        Updates CONFIG and results dictionaries.
    """
    allowed_config = ["batch_size", "num_epochs", "learning_rate", "weight_decay"]
    allowed_results = ["top_k", "top_p", "temperature"]

    for key in allowed_config:
        if key in params:
            CONFIG[key] = params[key]
    for key in allowed_results:
        if key in params:
            results[key] = params[key]
    if "auto_save" in params:
        global AUTO_SAVE
        AUTO_SAVE = params["auto_save"]

def get_model(client_id):
    """
    Loads and returns the model and tokenizer for a given client_id, using a cache for efficiency.
    Args:
        client_id (str): The client/user identifier.
    Returns:
        tuple: (model, tokenizer)
    Logic:
    - Uses a lock to ensure thread safety.
    - Loads from disk if not cached, otherwise returns cached model.
    - If client_id is None, loads the default model.
    """
    with cache_lock:
        if client_id not in model_locks:
            model_locks[client_id] = threading.Lock()

    with model_locks[client_id]:
        if client_id not in model_cache:
            model_path = f"./flan_models/{client_id}" if client_id else CONFIG["model_name"]
            try:
                tokenizer = T5Tokenizer.from_pretrained(model_path)
                model = T5ForConditionalGeneration.from_pretrained(model_path)
                model_cache[client_id] = (model, tokenizer)
                print(f"[INIT] Model loaded for client '{client_id}'")
            except Exception as e:
                print(f"[ERROR] Failed to load model for {client_id}: {e}")
                raise

    return model_cache[client_id]

def train_model(dataset: Dataset, client_id):
    """
    Fine-tunes the model for a specific client using the provided dataset.
    Args:
        dataset (Dataset): HuggingFace Dataset object for training.
        client_id (str): The client/user identifier.
    Side Effects:
        Trains and saves the model and tokenizer to disk.
    """
    model, tokenizer = get_model(client_id)
    training_args = TrainingArguments(
        output_dir=f"./flan_models/{client_id}",
        per_device_train_batch_size=CONFIG["batch_size"],
        num_train_epochs=CONFIG["num_epochs"],
        learning_rate=CONFIG["learning_rate"],
        weight_decay=CONFIG["weight_decay"],
        logging_steps=CONFIG["logging_steps"],
        save_total_limit=1,
        fp16=CONFIG["fp16"]
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=dataset
    )

    try:
        trainer.train()
        trainer.save_model()
        tokenizer.save_pretrained(training_args.output_dir)
        print(f"[TRAIN] Model trained and saved for {client_id}")
    except Exception as e:
        print(f"[ERROR] Training failed for {client_id}: {e}")

def generate_response(prompt, client_id=None):
    """
    Generates a response from the model for a given prompt and client.
    Args:
        prompt (str): The user's input message.
        client_id (str, optional): The client/user identifier.
    Returns:
        str: The generated response text.
    Logic:
    - Loads the model and tokenizer for the client.
    - Encodes the prompt and generates a response using configured decoding parameters.
    - Decodes and returns the generated text.
    """
    model, tokenizer = get_model(client_id)
    input_ids = tokenizer(prompt, return_tensors="pt").input_ids
    output = model.generate(
        input_ids,
        max_length=CONFIG["max_length"],
        top_k=results["top_k"],
        top_p=results["top_p"],
        temperature=results["temperature"],
        do_sample=True
    )
    return tokenizer.decode(output[0], skip_special_tokens=True)

def learn_from_dialogue(prompt, response, client_id=None):
    """
    Triggers model fine-tuning on a single prompt-response pair for a client.
    Args:
        prompt (str): The user's input.
        response (str): The model's response.
        client_id (str, optional): The client/user identifier.
    Side Effects:
        Fine-tunes the model on the new data.
    """
    data = {"input": [prompt], "target": [response]}
    dataset = Dataset.from_dict(data)
    train_model(dataset, client_id)

def learn_from_chunk(chunk, client_id=None):
    """
    Triggers model fine-tuning on a single chunk of data for a client.
    Args:
        chunk (str): The chunk of text to learn from.
        client_id (str, optional): The client/user identifier.
    Side Effects:
        Fine-tunes the model on the new data.
    """
    data = {"input": [chunk], "target": ["Understood."]}
    dataset = Dataset.from_dict(data)
    train_model(dataset, client_id)

def adjust_generation_by_rating(rating):
    """
    Adjusts generation parameters based on user feedback rating.
    Args:
        rating (int): User rating (1-5).
    Side Effects:
        Updates the temperature and top_p parameters.
    Logic:
    - Higher ratings make the model more creative (higher temperature/top_p).
    - Lower ratings make the model more conservative.
    """
    if rating >= 4:
        results["temperature"] = min(results["temperature"] + 0.05, 1.0)
        results["top_p"] = min(results["top_p"] + 0.05, 1.0)
    elif rating <= 2:
        results["temperature"] = max(results["temperature"] - 0.05, 0.5)
        results["top_p"] = max(results["top_p"] - 0.05, 0.5)
