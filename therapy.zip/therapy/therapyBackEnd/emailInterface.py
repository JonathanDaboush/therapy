import os
import re
import smtplib
import threading
from email.message import EmailMessage
from dotenv import load_dotenv

load_dotenv()

EMAIL_REGEX = r"^[^@\s]+@[^@\s]+\.[^@\s]+$"
LOCK = threading.Lock()

class EmailService:
    """
    EmailService handles sending emails using SMTP with configuration from environment variables.
    """

    def __init__(self):
        """
        Initializes the email service with configuration loaded from environment variables.
        """
        self.config = {
            "enabled": os.getenv("EMAIL_ENABLED", "True") == "True",
            "smtp_server": os.getenv("EMAIL_SMTP_SERVER", "smtp.gmail.com"),
            "smtp_port": int(os.getenv("EMAIL_SMTP_PORT", 465)),
            "smtp_user": os.getenv("EMAIL_SMTP_USER"),
            "smtp_password": os.getenv("EMAIL_SMTP_PASSWORD"),
            "sender_name": os.getenv("EMAIL_SENDER_NAME", "TherapyAI"),
            "sender_address": os.getenv("EMAIL_SENDER_ADDRESS"),
            "use_ssl": os.getenv("EMAIL_USE_SSL", "True") == "True",
            "use_tls": os.getenv("EMAIL_USE_TLS", "False") == "True",
            "default_subject": os.getenv("EMAIL_DEFAULT_SUBJECT", "Notification")
        }

    def validate_email(self, email):
        """
        Validates the email address format using a regular expression.
        Args:
            email (str): The email address to validate.
        Returns:
            bool: True if the email is valid, False otherwise.
        """
        return re.match(EMAIL_REGEX, email) is not None

    def send_email(self, to_email, subject, body):
        """
        Sends an email to the specified recipient.
        Args:
            to_email (str): Recipient's email address.
            subject (str): Subject of the email.
            body (str): Body content of the email.
        Returns:
            str: Success or error message.
        Logic:
        - Checks if the email service is enabled.
        - Validates the recipient's email format.
        - Constructs the email message.
        - Uses a thread lock to ensure thread-safe sending.
        - Chooses SSL or TLS based on configuration.
        - Logs in to the SMTP server and sends the message.
        - Returns a success message or error details.
        """
        if not self.config["enabled"]:
            return "Email service disabled."

        if not self.validate_email(to_email):
            return "Invalid email format."

        message = EmailMessage()
        message["From"] = f"{self.config['sender_name']} <{self.config['sender_address']}>"
        message["To"] = to_email
        message["Subject"] = subject or self.config["default_subject"]
        message.set_content(body or "No content provided.")

        try:
            with LOCK:
                if self.config["use_ssl"]:
                    server = smtplib.SMTP_SSL(self.config["smtp_server"], self.config["smtp_port"])
                else:
                    server = smtplib.SMTP(self.config["smtp_server"], self.config["smtp_port"])
                    if self.config["use_tls"]:
                        server.starttls()

                server.login(self.config["smtp_user"], self.config["smtp_password"])
                server.send_message(message)
                server.quit()

            return "Email sent successfully."
        except Exception as e:
            return f"Failed to send email: {str(e)}"

# Singleton instance to be used throughout the app
emailServiceInstance = EmailService()
