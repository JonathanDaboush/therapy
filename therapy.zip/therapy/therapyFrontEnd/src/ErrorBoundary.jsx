import React from 'react';

/**
 * ErrorBoundary is a React component that catches JavaScript errors
 * anywhere in its child component tree, logs those errors, and displays
 * a fallback UI instead of the component tree that crashed.
 *
 * Props:
 * - children: The child components to render inside the error boundary.
 *
 * How it works:
 * - If a child component throws an error, ErrorBoundary catches it,
 *   updates its state, and renders a fallback UI.
 * - The error is also logged to the console for debugging.
 */
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    // State tracks if an error has occurred and stores the error object
    this.state = { hasError: false, error: null };
  }

  // Update state so the next render shows the fallback UI
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  // Log error details for debugging
  componentDidCatch(error, errorInfo) {
    console.error('Error caught in boundary:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      // Render fallback UI if an error was caught
      return (
        <div style={{ color: 'red' }}>
          <h2>Something went wrong.</h2>
          <pre>{this.state.error?.toString()}</pre>
        </div>
      );
    }

    // Render children if no error
    return this.props.children;
  }
}

export default ErrorBoundary;
