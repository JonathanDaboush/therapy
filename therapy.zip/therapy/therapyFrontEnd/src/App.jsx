import { useState, useEffect } from 'react';
import LoggedOutInterface from './LoggedOutInterface';
import LoggedInInterface from './LoggedInInterface';
import { isTokenExpired } from "./utils/auth";

/**
 * App is the root component that manages authentication state and
 * determines whether to show the logged-in or logged-out interface.
 * 
 * How it works:
 * - On mount, checks for a valid JWT token and username in localStorage.
 * - If both are present and the token is not expired, sets the username state (user is logged in).
 * - If not, clears any stale token/username from localStorage (user is logged out).
 * - Renders LoggedOutInterface if no user is logged in, otherwise renders LoggedInInterface.
 * - Passes setTheUsername to child components so they can update authentication state.
 */
function App() {
  // State for the current username (empty string means not logged in)
  const [username, setUsername] = useState("");

  useEffect(() => {
    const token = localStorage.getItem("token");
    const savedUsername = localStorage.getItem("username");

    // If token and username exist and token is valid, log in user
    if (token && !isTokenExpired(token) && savedUsername) {
      setUsername(savedUsername);
    } else {
      // Otherwise, clear any stale credentials
      localStorage.removeItem("token");
      localStorage.removeItem("username");
    }
  }, []);

  return (
    <div>
      {username === "" 
        ? <LoggedOutInterface setTheUsername={setUsername} /> 
        : <LoggedInInterface setTheUsername={setUsername} username={username} />
      }
    </div>
  );
}

export default App;
