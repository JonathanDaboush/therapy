import React, { useState } from 'react';
import axios from './axiosConfig';

/**
 * ForgotPassword component allows users to request a password reset email.
 * 
 * Props:
 * - switchTab: Function to change the authentication tab (e.g., to "login" or "signup").
 * - email (optional): Pre-fills the email field if provided.
 * 
 * How it works:
 * - Displays a form for the user to enter their email address.
 * - Validates the email format before submitting.
 * - On submit, sends a POST request to the backend /forgotPassword endpoint.
 * - If the request is successful, clears the form and shows a confirmation message.
 * - If the request fails, displays an error message.
 * - Provides buttons to switch to Login or Sign Up forms.
 */
const ForgotPassword = (props) => {
    // State for the user's email address (pre-filled if provided via props)
    const [email, setEmail] = useState(props.email || "");
    // State for displaying info or error messages
    const [message, setMessage] = useState("");
    // API base URL from environment variable
    const API_URL = process.env.REACT_APP_API_URL;

    // Regular expression for validating email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    // Handles the password reset form submission
    const handleSubmit = async (e) => {
        e.preventDefault();

        // Validate email format
        if (!emailRegex.test(email)) {
            alert("Please enter a valid email address.");
            return;
        }

        try {
            // Send password reset request to backend
            await axios.post(`${API_URL}/forgotPassword`, {
                email,
                subject: "Password Reset"
            });
            setEmail("");
            setMessage(`Reset link sent to ${email} if the account exists.`);
        } catch {
            setMessage("Failed to send password reset request.");
        }
    };

    return (
        <div>
            <h2>Forgot Password</h2>
            <form onSubmit={handleSubmit}>
                <label>Email:
                    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                </label>
                <br />
                <button type="submit">Send Reset Link</button>
            </form>
            {/* Display info or error messages */}
            {message && <p>{message}</p>}
            <div>
                {/* Button to switch to Login form */}
                <button onClick={() => props.switchTab("login")}>Login</button>
                {/* Button to switch to Sign Up form */}
                <button onClick={() => props.switchTab("signup")}>Sign Up</button>
            </div>
        </div>
    );
};

export default ForgotPassword;
