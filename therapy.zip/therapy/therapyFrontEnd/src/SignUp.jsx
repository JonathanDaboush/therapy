import React, { useState } from 'react';
import axios from './axiosConfig';

/**
 * SignUp component handles user registration.
 * 
 * Props:
 * - switchTab: Function to change the authentication tab (e.g., to "login" or "forgotPassword").
 * 
 * How it works:
 * - Displays a sign-up form with username, email, and password fields.
 * - Validates the email and password format before submitting.
 * - On submit, sends a POST request to the backend /signUp endpoint.
 * - If sign-up is successful, clears the form, shows a success alert, and switches to the login tab.
 * - If sign-up fails, displays an error message.
 * - Provides buttons to switch to Login or Forgot Password forms.
 */
const SignUp = (props) => {
    // State for the username (chosen by the user)
    const [username, setUsername] = useState("");
    // State for the user's email address
    const [email, setEmail] = useState("");
    // State for the user's password
    const [password, setPassword] = useState("");
    // State for displaying error or info messages
    const [message, setMessage] = useState("");
    // API base URL from environment variable
    const API_URL = process.env.REACT_APP_API_URL;

    // Regular expressions for validating email and password
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{6,}$/;

    // Handles the sign-up form submission
    const handleSignUp = async (e) => {
        e.preventDefault();

        // Validate email format
        if (!emailRegex.test(email)) {
            alert("Please enter a valid email address.");
            return;
        }

        // Validate password format
        if (!passwordRegex.test(password)) {
            alert("Password must include uppercase, lowercase, number, and special character.");
            return;
        }

        try {
            // Send sign-up request to backend
            const response = await axios.post(`${API_URL}/signUp`, {
                new_username: username,
                new_email: email,
                new_password: password,
                subject: "Welcome to TherapyAI"
            });

            // If sign-up is successful, clear form and switch to login
            if (response.data.message) {
                setUsername("");   
                setEmail("");      
                setPassword("");  
                alert("Sign up successful!");
                props.switchTab("login");
            } else {
                setMessage(response.data.response || "Sign up failed.");
            }
        } catch {
            setMessage("An error occurred during sign up.");
        }
    };

    return (
        <div>
            <h1>Sign Up</h1>
            <form onSubmit={handleSignUp}>
                <label>Username:
                    <input type="text" value={username} onChange={e => setUsername(e.target.value)} />
                </label>
                <br />
                <label>Email:
                    <input type="email" value={email} onChange={e => setEmail(e.target.value)} />
                </label>
                <br />
                <label className="tooltip">Password:
                    <span className="tooltip-text">
                        Must include uppercase, lowercase, number, and symbol.
                    </span>
                    <input type="password" value={password} onChange={e => setPassword(e.target.value)} />
                </label>
                <br />
                <button type="submit">Sign Up</button>
            </form>
            {/* Display error or info messages */}
            {message && <div>{message}</div>}
            <div>
                {/* Button to switch to Login form */}
                <button onClick={() => props.switchTab("login")}>Login</button>
                {/* Button to switch to Forgot Password form */}
                <button onClick={() => props.switchTab("forgotPassword")}>Forgot Password</button>
            </div>
        </div>
    );
};

export default SignUp;
