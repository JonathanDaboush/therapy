import React, { useState } from 'react';
import axios from './axiosConfig';

/**
 * DeleteAccount component allows the user to delete their account.
 * 
 * Props:
 * - username: The username (client ID) of the currently logged-in user.
 * 
 * How it works:
 * - Displays a form for the user to enter their email address for confirmation.
 * - On submit, sends a POST request to the backend /deleteAccount endpoint with the client ID, email, and a subject.
 * - Includes the user's JWT token in the request headers for authentication.
 * - Shows an alert if the account was deleted successfully or if there was an error.
 */
const DeleteAccount = (props) => {
    // State for the user's email address (required for confirmation)
    let [email, setEmail] = useState("");
    // State for the username/client ID (from props)
    let [username, setUsername] = useState(props.username);
    // API base URL from environment variable
    const API_URL = process.env.REACT_APP_API_URL;

    // Handles the account deletion form submission
    const handleDelete = async (e) => {
        e.preventDefault();
        try {
            // Send delete account request to backend with authentication
            const response = await axios.post(`${API_URL}/deleteAccount`, {
                client_id: username,
                to_email: email,
                subject: "Account Deletion"
            }, {
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`
                }
            });
            if (response.data.message) {
                alert("Account deleted successfully.");
                // Optionally redirect or perform other actions here
            } else {
                alert("Failed to delete account.");
            }
        } catch (err) {
            alert("Failed to delete account.");
        }
    }

    return (
        <div>
            <h1>Delete Account</h1>
            <form onSubmit={handleDelete}>
                <label>
                    Email:
                    <input
                        type="email"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                    />
                </label>
                <br />
                <button type="submit">Delete Account</button>
            </form>
        </div>
    );
};

export default DeleteAccount;