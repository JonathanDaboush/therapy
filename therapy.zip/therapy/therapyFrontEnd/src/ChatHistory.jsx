import React, { useState, useEffect, forwardRef, useImperativeHandle } from 'react';
import axios from './axiosConfig';
import InputBox from "./InputBox";

/**
 * ChatHistory component displays and manages the user's chat history.
 * 
 * Props:
 * - client_id: The unique identifier for the current user/client whose chat history is shown.
 * 
 * How it works:
 * - Fetches chat history from the backend when the component mounts or when client_id changes.
 * - Displays each chat entry using the InputBox component, allowing editing and deletion.
 * - Provides methods for editing and deleting conversations, sending requests to the backend with JWT authentication.
 * - Exposes a refresh method to parent components via ref.
 */
const ChatHistory = forwardRef((props, ref) => {
    // State for the list of chat entries
    const [chatHistory, setChatHistory] = useState([]);
    // State for displaying info or error messages
    const [message, setMessage] = useState("");
    // API base URL from environment variable
    const API_URL = process.env.REACT_APP_API_URL;

    // Fetch chat history from backend
    const getChatHistory = async () => {
        try {
            const res = await axios.get(`${API_URL}/getChat`, {
                params: { client_id: props.client_id },
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`
                }
            });
            // Map backend data to expected format for InputBox
            setChatHistory(
                (res.data || []).map(pair => ({
                    id: pair.id,
                    input: pair.input,
                    response: pair.response
                }))
            );
            setMessage("Chat history loaded!");
        } catch (err) {
            setMessage("Failed to load chat history.");
        }
    };

    // Fetch chat history when component mounts or client_id changes
    useEffect(() => {
        getChatHistory();
    }, [props.client_id]);

    // Expose refresh method to parent components
    useImperativeHandle(ref, () => ({
        refresh: getChatHistory
    }));

    // Handles editing a conversation entry
    const handleEdit = async (conversation_id, newInput, newResponse, new_date) => {
        try {
            await axios.post(`${API_URL}/editChat`, {
                client_id: props.client_id,
                conversation_id,
                newInput,
                newResponse,
                new_date
            }, {
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`
                }
            });
            setMessage("Conversation updated!");
            getChatHistory();
        } catch (err) {
            setMessage("Failed to update conversation.");
        }
    };

    // Handles deleting a conversation entry
    const handleDelete = async (conversation_id) => {
        try {
            await axios.delete(`${API_URL}/removeChat`, {
                data: {
                    client_id: props.client_id,
                    conversation_id
                },
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`
                }
            });
            setChatHistory(prev => prev.filter(chat => chat.id !== conversation_id));
            setMessage("Conversation deleted!");
        } catch (err) {
            setMessage("Failed to delete conversation.");
        }
    };

    return (
        <div>
            {/* Render each chat entry using InputBox */}
            {chatHistory.map((chat) => (
                <div key={chat.id}>
                    <InputBox
                        id={chat.id}
                        input={chat.input}
                        response={chat.response}
                        onEdit={(newInput, newResponse, new_date) =>
                            handleEdit(chat.id, newInput, newResponse, new_date)
                        }
                        onDelete={() => handleDelete(chat.id)}
                    />
                </div>
            ))}
            {/* Display info or error messages */}
            {message && <div>{message}</div>}
        </div>
    );
});

export default ChatHistory;