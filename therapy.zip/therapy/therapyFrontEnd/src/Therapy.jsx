import React, { useState } from 'react';
import axios from './axiosConfig';
import ChatHistory from "./ChatHistory";

/**
 * Therapy component allows the user to send messages to the therapist AI and view responses.
 * 
 * Props:
 * - username: The username (client ID) of the currently logged-in user.
 * 
 * How it works:
 * - Displays a form for the user to enter a message.
 * - Sanitizes the message to prevent XSS attacks.
 * - Validates the message length before sending.
 * - Sends the message to the backend /response endpoint using a GET request with JWT authentication.
 * - Displays the therapist's response below the form.
 * - Shows the user's chat history using the ChatHistory component.
 */
function Therapy(props){
    // State for the user's message input
    const [message, setMessage] = useState("");
    // State for the therapist's response
    const [responseMsg, setResponseMsg] = useState("");
    // Username/client ID, taken from props
    const [username] = useState(props.username);
    // API base URL from environment variable
    const API_URL = process.env.REACT_APP_API_URL;

    // Sanitizes user input to prevent XSS
    const sanitize = (text) => {
        const temp = document.createElement("div");
        temp.textContent = text;
        return temp.innerHTML;
    };

    return (
        <div>
            <h1>Therapy</h1>
            <form onSubmit={async (e) => {
                e.preventDefault();
                try {
                    // Validate message length
                    if (!message || message.trim().length < 3 || message.length > 1000) {
                        setResponseMsg("Message must be between 3 and 1000 characters.");
                        return;
                    }

                    // Sanitize the message before sending
                    const cleanMessage = sanitize(message);

                    // Send the message to the backend /response endpoint
                    const response = await axios.get(`${API_URL}/response`, {
                        params: {
                            message: cleanMessage,
                            client_id: username
                        },
                        headers: {
                            Authorization: `Bearer ${localStorage.getItem("token")}`
                        }
                    });

                    // Clear the input and display the therapist's response
                    setMessage("");
                    setResponseMsg(response.data.response);
                } catch (err) {
                    setMessage("");
                    setResponseMsg("Failed to get response.");
                }
            }}>
                <label>
                    Message:
                    <textarea
                        value={message}
                        onChange={e => setMessage(e.target.value)}
                    />
                </label>
                <br />
                <button type="submit">Send Message</button>
            </form>
            {/* Display the therapist's response */}
            {responseMsg && <div><strong>Therapist:</strong> {responseMsg}</div>}
            {/* Show the user's chat history */}
            <ChatHistory client_id={username} />
        </div>
    );
}

export default Therapy;