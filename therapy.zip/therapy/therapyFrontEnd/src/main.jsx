import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import ErrorBoundary from './ErrorBoundary'

/**
 * main.jsx is the entry point for the React application.
 * 
 * How it works:
 * - Wraps the entire app in React's StrictMode for highlighting potential problems.
 * - Wraps the app in an ErrorBoundary to catch and display errors gracefully.
 * - Renders the App component into the root DOM element.
 */

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>
);

