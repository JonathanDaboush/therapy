import React, { useState } from 'react';
import axios from './axiosConfig';

/**
 * Feedback component allows the user to submit a rating for their experience.
 * 
 * Props:
 * - None required, but you could extend to accept user/session info if needed.
 * 
 * How it works:
 * - Displays a form with a numeric input for rating (1 to 5).
 * - Validates the rating before submitting.
 * - On submit, sends a POST request to the backend /rating endpoint with the rating and JWT token.
 * - Shows a message indicating if the feedback was submitted successfully or if there was an error.
 */
function Feedback(props) {
    // State for the user's rating (1 to 5)
    const [rating, setRating] = useState(1);
    // State for displaying info or error messages
    const [message, setMessage] = useState("");
    // API base URL from environment variable
    const API_URL = process.env.REACT_APP_API_URL;

    // Handles the feedback form submission
    const submitFeedback = async (e) => {
        e.preventDefault();
        try {
            // Validate rating range
            if (rating < 1 || rating > 5) {
                setMessage("Rating must be between 1 and 5.");
                return;
            }

            // Send the rating to the backend with JWT authentication
            await axios.post(`${API_URL}/rating`, {
                rating
            }, {
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`
                }
            });

            setMessage("Feedback submitted successfully!");
        } catch (err) {
            setMessage("Failed to submit feedback.");
        }
    };

    return (
        <form onSubmit={submitFeedback}>
            <label>
                Rating:
                <input
                    type="number"
                    min="1"
                    max="5"
                    value={rating}
                    onChange={e => setRating(Number(e.target.value))}
                />
            </label>
            <br />
            <button type="submit">Submit Feedback</button>
            {/* Display info or error messages */}
            {message && <div>{message}</div>}
        </form>
    );
}

export default Feedback;