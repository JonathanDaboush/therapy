import React, { useState, useEffect } from 'react';
import axios from './axiosConfig';

/**
 * Login component handles user authentication.
 * 
 * Props:
 * - setTheUsername: Function to update the username in the parent (used after successful login).
 * - switchTab: Function to change the authentication tab (e.g., to "signup" or "forgotPassword").
 * 
 * How it works:
 * - Displays a login form with username (email) and password fields.
 * - Validates the email and password format before submitting.
 * - On submit, sends a POST request to the backend /logIn endpoint.
 * - If login is successful, saves the JWT token and username to localStorage and updates the parent.
 * - If login fails, displays an error message.
 * - Provides buttons to switch to Sign Up or Forgot Password forms.
 */
const Login = (props) => {
    // State for the username (email)
    const [username, setUsername] = useState("");
    // State for the password
    const [password, setPassword] = useState("");
    // State for displaying error or info messages
    const [message, setMessage] = useState("");
    // API base URL from environment variable
    const API_URL = process.env.REACT_APP_API_URL;

    // On mount, pre-fill username if saved in localStorage
    useEffect(() => {
        const savedUsername = localStorage.getItem("username");
        if (savedUsername) setUsername(savedUsername);
    }, []);

    // Regular expressions for validating email and password
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{6,}$/;

    // Handles the login form submission
    const handleLogin = async (e) => {
        e.preventDefault();

        // Validate email format
        if (!emailRegex.test(username)) {
            alert("Please enter a valid email address.");
            return;
        }

        // Validate password format
        if (!passwordRegex.test(password)) {
            alert("Password must include uppercase, lowercase, number, and special character.");
            return;
        }

        try {
            // Send login request to backend
            const response = await axios.post(`${API_URL}/logIn`, { username, password });

            // If login is successful, save token and username, update parent, and reset fields
            if (response.data && response.data.token) {
                localStorage.setItem("token", response.data.token);
                localStorage.setItem("username", response.data.client_id);
                props.setTheUsername(response.data.client_id);
                setUsername("");   // Reset input
                setPassword("");   // Reset input
                alert("Login successful!");
            }
            // If login fails, show error message
            else {
                setMessage("Invalid username or password.");
            }
        } catch {
            setMessage("An error occurred during login.");
        }
    };

    return (
        <div>
            <h1>Login</h1>
            <form onSubmit={handleLogin}>
                <label>Username (Email):
                    <input type="text" value={username} onChange={e => setUsername(e.target.value)} />
                </label>
                <br />
                <label className="tooltip">Password:
                    <span className="tooltip-text">
                        Must include uppercase, lowercase, number, and symbol.
                    </span>
                    <input type="password" value={password} onChange={e => setPassword(e.target.value)} />
                </label>
                <br />
                <button type="submit">Login</button>
            </form>
            {/* Display error or info messages */}
            {message && <div>{message}</div>}
            <div>
                {/* Button to switch to Sign Up form */}
                <button onClick={() => props.switchTab("signup")}>Sign Up</button>
                {/* Button to switch to Forgot Password form */}
                <button onClick={() => props.switchTab("forgotPassword")}>Forgot Password</button>
            </div>
        </div>
    );
};

export default Login;
