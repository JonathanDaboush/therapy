import React, { useState } from 'react';
import Login from './Login';
import SignUp from './SignUp';
import ForgotPassword from './ForgotPassword';

/**
 * LoggedOutInterface manages the authentication flow for users who are not logged in.
 * 
 * Props:
 * - setTheUsername: Function to update the username in the parent (used after successful login).
 * 
 * How it works:
 * - Uses internal state 'tab' to track which authentication form is currently shown ("login", "signup", or "forgotPassword").
 * - Renders the appropriate component based on the selected tab.
 * - Passes the setTab function as 'switchTab' prop to child components so they can trigger tab changes (e.g., "Go to Sign Up" link).
 * - Passes setTheUsername to Login so the parent can update authentication state after login.
 */
const LoggedOutInterface = (props) => {
    // 'tab' state determines which authentication form is displayed
    const [tab, setTab] = useState("login");

    if (tab === "login") {
        // Show the Login form
        return (
            <div>
                <Login switchTab={setTab} setTheUsername={props.setTheUsername} />
            </div>
        );
    } else if (tab === "signup") {
        // Show the Sign Up form
        return (
            <div>
                <SignUp switchTab={setTab} />
            </div>
        );
    } else if (tab === "forgotPassword") {
        // Show the Forgot Password form
        return (
            <div>
                <ForgotPassword switchTab={setTab} />
            </div>
        );
    }
    // Fallback: render nothing if tab is invalid
    return null;
};

export default LoggedOutInterface;