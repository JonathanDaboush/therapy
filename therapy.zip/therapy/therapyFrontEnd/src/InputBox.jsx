import React, { useState } from 'react';

/**
 * InputBox component allows a user to view, edit, and delete a single chat entry.
 * 
 * Props:
 * - id: Unique identifier for this chat entry (not used directly here, but useful for parent components).
 * - input: The original user message for this chat entry.
 * - response: The therapist's response for this chat entry.
 * - onEdit: Function to call when the user submits an edit. Receives (newInput, newResponse, newDate).
 * - onDelete: Function to call when the user clicks the delete button. No arguments.
 * 
 * How it works:
 * - Displays input fields pre-filled with the current input, response, and date.
 * - Lets the user edit these fields and submit changes.
 * - Calls onEdit with the updated values when the form is submitted.
 * - Calls onDelete when the delete button is clicked.
 */
const InputBox = ({ id, input, response, onEdit, onDelete }) => {
    // State for the editable user input field
    const [editInput, setEditInput] = useState(input);
    // State for the editable therapist response field
    const [editResponse, setEditResponse] = useState(response);
    // State for the editable date field, defaulting to today
    const [editDate, setEditDate] = useState(new Date().toISOString().slice(0, 10));

    // Handles the form submission for editing a chat entry
    const handleEditSubmit = (e) => {
        e.preventDefault();
        // Calls the onEdit prop with the updated values
        onEdit(editInput, editResponse, editDate);
    };

    return (
        <div>
            <form onSubmit={handleEditSubmit}>
                {/* Input field for editing the user's message */}
                <input
                    type="text"
                    value={editInput}
                    onChange={e => setEditInput(e.target.value)}
                    placeholder="Input"
                />
                {/* Input field for editing the therapist's response */}
                <input
                    type="text"
                    value={editResponse}
                    onChange={e => setEditResponse(e.target.value)}
                    placeholder="Response"
                />
                {/* Date picker for editing the date of the conversation */}
                <input
                    type="date"
                    value={editDate}
                    onChange={e => setEditDate(e.target.value)}
                />
                {/* Button to submit the edits */}
                <button type="submit">Edit</button>
                {/* Button to delete the chat entry */}
                <button type="button" onClick={onDelete}>Delete</button>
            </form>
        </div>
    );
};

export default InputBox;