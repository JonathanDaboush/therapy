import React, { useState } from 'react';
import LoggedInInterface from './LoggedInInterface';
import DeleteAccount from './DeleteAccount';

/**
 * SignedIn manages the main interface for authenticated users,
 * allowing them to access the main app or delete their account.
 * 
 * Props:
 * - username: The username of the currently logged-in user.
 * 
 * How it works:
 * - Uses 'tab' state to determine which view to show: main app or delete account.
 * - When 'loggedIn', shows the main app interface and a button to switch to account deletion.
 * - When 'DeleteAccount', shows the delete account form and a button to return to the main app.
 * - If an unexpected tab value is encountered, displays an error message.
 */
const SignedIn = (props) => {
    // State for the current username (passed to child components)
    const [username, setUsername] = useState(props.username);
    // State to control which tab/view is shown
    const [tab, setTab] = useState("loggedIn");

    if (tab === "loggedIn") {
        // Main app interface with a button to go to Delete Account
        return (
            <div>
                <button onClick={() => setTab("DeleteAccount")}>Delete Account</button>
                <LoggedInInterface username={username} />
            </div>
        );
    } else if (tab === "DeleteAccount") {
        // Delete Account view with a button to return to main app
        return (
            <div>
                <button onClick={() => setTab("loggedIn")}>Back to App</button>
                <DeleteAccount username={username} />
            </div>
        );
    } else {
        // Fallback for unexpected state
        return (
            <div>
                <h1>Something went wrong</h1>
                <p>Please try again later.</p>
            </div>
        );
    }
};

export default SignedIn;
