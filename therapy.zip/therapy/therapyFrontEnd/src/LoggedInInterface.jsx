import React, { useState } from 'react';
import Therapy from './Therapy';
import Feedback from './Feedback';
import FineTuning from './fineTuning';
import axios from './axiosConfig';

/**
 * LoggedInInterface is the main interface shown to a logged-in user.
 * 
 * Props:
 * - username: The username of the currently logged-in user.
 * - setTheUsername: Function to update the username in the parent (used for logout).
 * 
 * How it works:
 * - Displays navigation buttons for Therapy, Feedback, and Fine-Tuning sections.
 * - Shows the selected section based on the user's choice.
 * - Passes the username/clientId to child components as needed.
 * - Provides a Logout button that clears the username and logs the user out.
 */
function LoggedInInterface(props) {
  // showOption controls which section is visible: 0 = Therapy, 1 = Feedback, 2 = FineTuning
  const [showOption, setShowOption] = useState(0);
  // Store the username locally for passing to child components
  const [username, setUsername] = useState(props.username);

  return (
    <>
      {/* Navigation buttons for switching between sections */}
      <button onClick={() => setShowOption(0)}>
        Therapy
      </button>
      <button onClick={() => setShowOption(1)}>
        Feedback
      </button>
      <button onClick={() => setShowOption(2)}>
        Fine-Tuning
      </button>
      {/* Logout button resets the username in the parent, logging the user out */}
      <button onClick={() => props.setTheUsername("")}>
        Logout
      </button>
      {/* Conditionally render the selected section */}
      {showOption === 0 && (
        <div id="page1"><Therapy username={username} /></div>
      )}
      {showOption === 1 && (
        <div id="page2"><Feedback username={username} /></div>
      )}
      {showOption === 2 && (
        <div id="page3"><FineTuning clientId={username} /></div>
      )}
    </>
  );
}

export default LoggedInInterface;