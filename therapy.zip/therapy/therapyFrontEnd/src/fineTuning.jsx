import React, { useState } from "react";

/**
 * FineTuning component allows the user to submit fine-tuning parameters and data for the AI model.
 * 
 * Props:
 * - clientId: The unique identifier for the current user/client.
 * 
 * How it works:
 * - Displays a form for the user to input FLAN data (JSON), number of epochs, batch size, learning rate, and weight decay.
 * - Validates and collects these parameters from the user.
 * - On submit, sends a POST request to the backend /fineTuning endpoint with all parameters and the user's JWT token.
 * - Shows a status message indicating if the fine-tuning request was successful or failed.
 */
const FineTuning = ({ clientId }) => {
  // State for FLAN data (JSON array as string)
  const [flanData, setFlanData] = useState("");
  // State for number of epochs
  const [numEpochs, setNumEpochs] = useState(3);
  // State for batch size
  const [batchSize, setBatchSize] = useState(8);
  // State for learning rate
  const [learningRate, setLearningRate] = useState(5e-5);
  // State for weight decay
  const [weightDecay, setWeightDecay] = useState(0.01);
  // State for status messages
  const [status, setStatus] = useState("");
  // API base URL from environment variable
  const API_URL = process.env.REACT_APP_API_URL;

  // Slider ranges for learning rate and weight decay
  const minLR = 1e-6, maxLR = 1e-3;
  const minWD = 0, maxWD = 0.1;

  // Handles the fine-tuning form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("Training started...");

    try {
      // Send fine-tuning parameters and data to backend
      const response = await fetch(`${API_URL}/fineTuning`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem("token")}`
        },
        body: JSON.stringify({
          client_id: clientId,
          flan_data: flanData,
          num_epochs: numEpochs,
          batch_size: batchSize,
          learning_rate: learningRate,
          weight_decay: weightDecay
        })
      });

      // Show status based on response
      if (response.ok) {
        setStatus("Training parameters updated successfully!");
      } else {
        setStatus("Training failed.");
      }
    } catch (err) {
      setStatus("Error: " + err.message);
    }
  };

  return (
    <div style={{ maxWidth: 600, margin: "auto" }}>
      <h2>Fine-Tune Model</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <strong>Client ID:</strong> {clientId}
        </div>
        <label>
          FLAN Data (JSON array):
          <textarea
            rows={8}
            style={{ width: "100%" }}
            value={flanData}
            onChange={(e) => setFlanData(e.target.value)}
            placeholder='[{"input": "...", "target": "..."}, ...]'
            required
          />
        </label>
        <br />
        <label>
          Epochs:
          <input
            type="number"
            min={1}
            value={numEpochs}
            onChange={(e) => setNumEpochs(e.target.value)}
          />
        </label>
        <br />
        <label>
          Batch Size:
          <input
            type="number"
            min={1}
            value={batchSize}
            onChange={(e) => setBatchSize(e.target.value)}
          />
        </label>
        <br />
        <label>
          Learning Rate: <span>{learningRate}</span>
          <input
            type="range"
            min={minLR}
            max={maxLR}
            step={1e-6}
            value={learningRate}
            onChange={(e) => setLearningRate(Number(e.target.value))}
            style={{ width: "100%" }}
          />
        </label>
        <br />
        <label>
          Weight Decay: <span>{weightDecay}</span>
          <input
            type="range"
            min={minWD}
            max={maxWD}
            step={0.001}
            value={weightDecay}
            onChange={(e) => setWeightDecay(Number(e.target.value))}
            style={{ width: "100%" }}
          />
        </label>
        <br />
        <button type="submit">Start Fine-Tuning</button>
      </form>
      {/* Display the status message */}
      <div style={{ marginTop: 20 }}>{status}</div>
    </div>
  );
};

export default FineTuning;