# therapyFrontEnd React Project

This project is the frontend for the TherapyAI platform, built with [React](https://react.dev/) and [Vite](https://vitejs.dev/). It provides a modern, fast, and interactive user interface for users to interact with the TherapyAI backend, manage their accounts, chat with the AI therapist, provide feedback, and fine-tune the AI model.

---

## Project Structure

- **React 18**: The core UI library for building user interfaces.
- **Vite**: A fast build tool and development server for modern web projects.
- **Zustand**: State management library for React.
- **React DnD**: Drag-and-drop utilities for React.
- **React RnD**: Resizable and draggable components.
- **@mui/material**: Material UI component library for consistent, accessible design.
- **pdf2docx / docx2pdf**: Libraries for PDF and DOCX file conversions (potentially for document upload or export features).

---

## Scripts

- `dev`: Runs the development server with hot module replacement.
- `build`: Builds the app for production.
- `preview`: Serves the production build locally for testing.

---

## Dependencies

- **react** / **react-dom**: Core React libraries.
- **zustand**: For global state management.
- **react-dnd** / **react-dnd-html5-backend**: For implementing drag-and-drop features.
- **react-rnd**: For resizable and draggable UI elements.
- **@mui/material**: Material UI components.
- **pdf2docx** / **docx2pdf**: For document conversion features.

### Dev Dependencies

- **@vitejs/plugin-react**: Vite plugin for React with fast refresh.
- **vite**: Build tool and dev server.
- **tailwindcss**: Utility-first CSS framework (if used in your styles).
- **postcss** / **autoprefixer**: For CSS processing and browser compatibility.

---

## Environment Variables

The frontend expects an environment variable for the backend API URL:

- `REACT_APP_API_URL` (see [src/.env](src/.env))

Example:
```
REACT_APP_API_URL=*********
```

---

## Usage

1. **Install dependencies:**
   ```sh
   npm install
   ```

2. **Start the development server:**
   ```sh
   npm run dev
   ```

3. **Build for production:**
   ```sh
   npm run build
   ```

4. **Preview the production build:**
   ```sh
   npm run preview
   ```

---

## Features

- **Authentication**: Sign up, log in, password reset, and account deletion.
- **Therapy Chat**: Chat interface with the AI therapist, including chat history.
- **Feedback**: Submit ratings to improve the AI.
- **Fine-Tuning**: Submit custom data and parameters to fine-tune the AI model.
- **Document Handling**: Support for PDF/DOCX conversion (if implemented in the UI).
- **Material UI**: Consistent, accessible design components.
- **Drag-and-Drop**: Interactive UI elements for enhanced user experience.

---

## Notes

- This project is intended to be used with the TherapyAI backend (FastAPI, see backend repo).
- Make sure to configure the backend URL in the `.env` file.
- For production deployment, ensure all environment variables are set appropriately and sensitive data is secured.

---

## License

This project is private and not intended for public distribution. Please contact the author for licensing information.

---

## Author

Developed by Jonathan Daboush